function onCreate()
	  makeLuaSprite('black1', 'black1', 0, 0);
        makeGraphic('black1',1920,1080,'ffffff')
	  addLuaSprite('black1', true);
        setObjectCamera('black1', 'camera');
	  setLuaSpriteScrollFactor('black1',0,0)
	  setProperty('black1.scale.x',2)
	  setProperty('black1.scale.y',2)
	  setProperty('black1.alpha',0)
end

function onStepHit()
	if curStep == 256 then
        		doTweenAlpha('black1', 'black1', 1, 1);
end
	if curStep == 272 then
        		doTweenAlpha('black1', 'black1', 0, 0.3);
end
	if curStep == 300 then
	  	removeLuaSprite('black1', true);
	end
end