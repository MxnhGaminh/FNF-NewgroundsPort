function onCreate()
	-- background shit
	makeLuaSprite('bg1', 'bg1', -800, -600)
	scaleObject('bg1', 2.5, 2.5)
	
	addLuaSprite('bg1', false)
	setProperty('bg1.antialiasing',false)
end

function onCreatePost()

	setProperty('gf.visible',false)
end