function onCreate()
	-- background shit
	makeLuaSprite('d_side_bg', 'd_side_bg', -600, -500)
	scaleObject('d_side_bg', 1.4, 1.4)
	makeLuaSprite('bg_shadow', 'bg_shadow', -600, -500)
	scaleObject('bg_shadow', 1.4, 1.4)
	
	addLuaSprite('d_side_bg', false)
	setProperty('d_side_bg.antialiasing',true)
	addLuaSprite('bg_shadow', true)
	setProperty('bg_shadow.antialiasing',true)
end

function onCreatePost()

	setProperty('gf.visible',false)
end