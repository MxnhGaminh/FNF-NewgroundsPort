local animsA = {'singLEFT-alt', 'singDOWN-alt', 'singUP-alt', 'singRIGHT-alt'}
local animsB = {'singLEFT', 'singDOWN', 'singUP', 'singRIGHT'}
local hitInARow = 0

function goodNoteHit(i, d, t, s)
    if not isSustainNote then
        hitInARow = getProperty(hitInARow)+ 1
    end
	if hitInARow >= 30 then -- the combo counter, you can edit this.
	    characterPlayAnim('bf', animsA[d + 1]);
	end
end

function noteMiss(id, direction, noteType, isSustainNote)
    if getProperty('songMisses')+ 1 then
		hitInARow = 0
	end
	if hitInARow == 0 then
	    characterPlayAnim('bf', animsB[d + 1]);
		hitInARow = 0
    end
end