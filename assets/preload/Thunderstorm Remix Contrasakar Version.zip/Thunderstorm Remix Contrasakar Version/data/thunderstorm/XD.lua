function opponentNoteHit(id,data,type,sus)
        triggerEvent('Screen Shake','0.1, 0.01','0.001, 0.1')
 end