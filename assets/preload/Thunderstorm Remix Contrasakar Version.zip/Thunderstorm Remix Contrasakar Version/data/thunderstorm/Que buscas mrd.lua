function onCreate()



        makeLuaText("MEJORADO POR: ", 'CONTRASAKAR', 0, 570, 120);




    setObjectCamera("MEJORADO POR: ", 'hud');
    setTextColor('MEJORADO POR: ', '0xFFFFFF')
    setTextSize('MEJORADO POR: ', 20);
    addLuaText("MEJORADO POR: ");
    setTextFont('MEJORADO POR: ', "vcr.ttf")
    setTextAlignment('MEJORADO POR: ', 'left')
end