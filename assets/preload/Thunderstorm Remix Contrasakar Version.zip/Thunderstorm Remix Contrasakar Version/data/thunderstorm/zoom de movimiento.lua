local angleshit = 2;
local anglevar = 2;
local angleshita = -2;
local anglevara = -2;
local angleshiter = 0;
local anglevarer = 0;

function onBeatHit()
	if curBeat >= 304 and curBeat < 336 then
		triggerEvent('Add Camera Zoom', 0.04,0.05)

		if curBeat % 2 == 0 then
			angleshit = anglevar;
		else
			angleshit = -anglevar;
		end
		setProperty('camHUD.angle',angleshit*3)
		setProperty('camGame.angle',angleshit*3)
		doTweenAngle('turn', 'camHUD', angleshit, stepCrochet*0.002, 'circOut')
		doTweenX('tuin', 'camHUD', -angleshit*8, crochet*0.001, 'linear')
		doTweenAngle('tt', 'camGame', angleshit, stepCrochet*0.002, 'circOut')
		doTweenX('ttrn', 'camGame', -angleshit*8, crochet*0.001, 'linear')
	else
		setProperty('camHUD.angle',0)
		setProperty('camHUD.x',0)
		setProperty('camHUD.x',0)
	end


	if curBeat >= 800000 and curBeat < 81000000 then
		triggerEvent('Add Camera Zoom', 0.04,0.05)

		if curBeat % 2 == 0 then
			angleshit = anglevar;
		else
			angleshit = -anglevar;
		end
		setProperty('camHUD.angle',angleshit*3)
		setProperty('camGame.angle',angleshit*3)
		doTweenAngle('turn', 'camHUD', angleshit, stepCrochet*0.002, 'circOut')
		doTweenX('tuin', 'camHUD', -angleshit*8, crochet*0.001, 'linear')
		doTweenAngle('tt', 'camGame', angleshit, stepCrochet*0.002, 'circOut')
		doTweenX('ttrn', 'camGame', -angleshit*8, crochet*0.001, 'linear')
	else
		setProperty('camHUD.angle',0)
		setProperty('camHUD.x',0)
		setProperty('camHUD.x',0)
	end
	if curBeat >= 9600000 and curBeat < 9000000 then
		triggerEvent('Add Camera Zoom', 0.04,0.05)

		if curBeat % 2 == 0 then
			angleshita = anglevara;
		else
			angleshita = -anglevara;
		end
		setProperty('camHUD.angle',angleshita*3)
		setProperty('camGame.angle',angleshita*3)
		doTweenAngle('turn', 'camHUD', angleshita, stepCrochet*0.002, 'circOut')
		doTweenX('tuin', 'camHUD', -angleshita*8, crochet*0.001, 'linear')
		doTweenAngle('tt', 'camGame', angleshita, stepCrochet*0.002, 'circOut')
		doTweenX('ttrn', 'camGame', -angleshita*8, crochet*0.001, 'linear')
	else
		setProperty('camHUD.angle',0)
		setProperty('camHUD.x',0)
		setProperty('camHUD.x',0)
	end

	if curBeat >= 11000002 and curBeat < 100000013 then
		triggerEvent('Add Camera Zoom', 0.04,0.05)

		if curBeat % 2 == 0 then
			angleshit = anglevar;
		else
			angleshit = -anglevar;
		end
		setProperty('camHUD.angle',angleshit*3)
		setProperty('camGame.angle',angleshit*3)
		doTweenAngle('turn', 'camHUD', angleshit, stepCrochet*0.002, 'circOut')
		doTweenX('tuin', 'camHUD', -angleshit*8, crochet*0.001, 'linear')
		doTweenAngle('tt', 'camGame', angleshit, stepCrochet*0.002, 'circOut')
		doTweenX('ttrn', 'camGame', -angleshit*8, crochet*0.001, 'linear')
	else
		setProperty('camHUD.angle',0)
		setProperty('camHUD.x',0)
		setProperty('camHUD.x',0)
	end


	if curBeat >= 672 and curBeat < 673 then-----------------------------------------------------
		triggerEvent('Add Camera Zoom', 0.04,0.05)

		if curBeat % 2 == 0 then
			angleshiter = anglevarer;
		else
			angleshiter = -anglevarer;
		end
		setProperty('camHUD.angle',angleshiter*3)
		setProperty('camGame.angle',angleshiter*3)
		doTweenAngle('turn', 'camHUD', angleshiter, stepCrochet*0.002, 'circOut')
		doTweenX('tuin', 'camHUD', -angleshiter*8, crochet*0.001, 'linear')
		doTweenAngle('tt', 'camGame', angleshiter, stepCrochet*0.002, 'circOut')
		doTweenX('ttrn', 'camGame', -angleshiter*8, crochet*0.001, 'linear')
	else
		setProperty('camHUD.angle',0)
		setProperty('camHUD.x',0)
		setProperty('camHUD.x',0)
	end

	if curBeat >= 688 and curBeat < 703 then
		triggerEvent('Add Camera Zoom', 0.04,0.05)

		if curBeat % 2 == 0 then
			angleshit = anglevar;
		else
			angleshit = -anglevar;
		end
		setProperty('camHUD.angle',angleshit*3)
		setProperty('camGame.angle',angleshit*3)
		doTweenAngle('turn', 'camHUD', angleshit, stepCrochet*0.002, 'circOut')
		doTweenX('tuin', 'camHUD', -angleshit*8, crochet*0.001, 'linear')
		doTweenAngle('tt', 'camGame', angleshit, stepCrochet*0.002, 'circOut')
		doTweenX('ttrn', 'camGame', -angleshit*8, crochet*0.001, 'linear')
	else
		setProperty('camHUD.angle',0)
		setProperty('camHUD.x',0)
		setProperty('camHUD.x',0)
	end

	if curBeat >= 704 and curBeat < 705 then
		triggerEvent('Add Camera Zoom', 0.04,0.05)

		if curBeat % 2 == 0 then
			angleshiter = anglevarer;
		else
			angleshiter = -anglevarer;
		end
		setProperty('camHUD.angle',angleshiter*3)
		setProperty('camGame.angle',angleshiter*3)
		doTweenAngle('turn', 'camHUD', angleshiter, stepCrochet*0.002, 'circOut')
		doTweenX('tuin', 'camHUD', -angleshiter*8, crochet*0.001, 'linear')
		doTweenAngle('tt', 'camGame', angleshiter, stepCrochet*0.002, 'circOut')
		doTweenX('ttrn', 'camGame', -angleshiter*8, crochet*0.001, 'linear')
	else
		setProperty('camHUD.angle',0)
		setProperty('camHUD.x',0)
		setProperty('camHUD.x',0)
	end

	if curBeat >= 768999 and curBeat < 8399991 then
		triggerEvent('Add Camera Zoom', 0.08,0.05)

		if curBeat % 2 == 0 then
			angleshit = anglevar;
		else
			angleshit = -anglevar;
		end
		setProperty('camHUD.angle',angleshit*3)
		setProperty('camGame.angle',angleshit*3)
		doTweenAngle('turn', 'camHUD', angleshit, stepCrochet*0.002, 'circOut')
		doTweenX('tuin', 'camHUD', -angleshit*8, crochet*0.001, 'linear')
		doTweenAngle('tt', 'camGame', angleshit, stepCrochet*0.002, 'circOut')
		doTweenX('ttrn', 'camGame', -angleshit*8, crochet*0.001, 'linear')
	else
		setProperty('camHUD.angle',0)
		setProperty('camHUD.x',0)
		setProperty('camHUD.x',0)
	end
	if curBeat >= 8329999 and curBeat < 8399993 then
		triggerEvent('Add Camera Zoom', 0.14,0.08)

		if curBeat % 2 == 0 then
			angleshiter = anglevarer;
		else
			angleshiter = -anglevarer;
		end
		setProperty('camHUD.angle',angleshiter*3)
		setProperty('camGame.angle',angleshiter*3)
		doTweenAngle('turn', 'camHUD', angleshiter, stepCrochet*0.002, 'circOut')
		doTweenX('tuin', 'camHUD', -angleshiter*8, crochet*0.001, 'linear')
		doTweenAngle('tt', 'camGame', angleshiter, stepCrochet*0.002, 'circOut')
		doTweenX('ttrn', 'camGame', -angleshiter*8, crochet*0.001, 'linear')
	else
		setProperty('camHUD.angle',0)
		setProperty('camHUD.x',0)
		setProperty('camHUD.x',0)
	end
end

function onStepHit()
	if curBeat >= 300000002 and curBeat < 1500000006 then
		if curStep % 4 == 0 then
			doTweenY('rrr', 'camHUD', -24, stepCrochet*0.002, 'circOut')
			doTweenY('rtr', 'camGame.scroll', 24, stepCrochet*0.002, 'sineIn')
		end
		if curStep % 4 == 2 then
			doTweenY('rir', 'camHUD', 0, stepCrochet*0.002, 'sineIn')
			doTweenY('ryr', 'camGame.scroll', 0, stepCrochet*0.002, 'sineIn')
		end
	end

	if curBeat >= 160000000 and curBeat < 180000008 then
		if curStep % 4 == 0 then
			doTweenY('rrr', 'camHUD', -24, stepCrochet*0.002, 'circOut')
			doTweenY('rtr', 'camGame.scroll', 24, stepCrochet*0.002, 'sineIn')
		end
		if curStep % 4 == 2 then
			doTweenY('rir', 'camHUD', 0, stepCrochet*0.002, 'sineIn')
			doTweenY('ryr', 'camGame.scroll', 0, stepCrochet*0.002, 'sineIn')
		end
	end

	if curBeat >= 1900000002 and curBeat < 2000000024 then
		if curStep % 4 == 0 then
			doTweenY('rrr', 'camHUD', -24, stepCrochet*0.002, 'circOut')
			doTweenY('rtr', 'camGame.scroll', 24, stepCrochet*0.002, 'sineIn')
		end
		if curStep % 4 == 2 then
			doTweenY('rir', 'camHUD', 0, stepCrochet*0.002, 'sineIn')
			doTweenY('ryr', 'camGame.scroll', 0, stepCrochet*0.002, 'sineIn')
		end
	end
	if curBeat >= 250000000006 and curBeat < 264000000 then
		if curStep % 4 == 0 then
			doTweenY('rrr', 'camHUD', -24, stepCrochet*0.002, 'circOut')
			doTweenY('rtr', 'camGame.scroll', 24, stepCrochet*0.002, 'sineIn')
		end
		if curStep % 4 == 2 then
			doTweenY('rir', 'camHUD', 0, stepCrochet*0.002, 'sineIn')
			doTweenY('ryr', 'camGame.scroll', 0, stepCrochet*0.002, 'sineIn')
		end
	end
end