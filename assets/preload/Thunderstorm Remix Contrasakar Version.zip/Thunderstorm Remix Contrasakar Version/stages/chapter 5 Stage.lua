function onCreate()
	-- background shit
	makeLuaSprite('chapter5bg', 'chapter5bg', -600, -300);
	setScrollFactor('chapter5bg', 0.9, 0.9);
	

	addLuaSprite('chapter5bg', false);
	
	close(true); --For performance reasons, close this script once the stage is fully loaded, as this script won't be used anymore after loading the stage
end